<nav class="navbar bg-body-tertiary shadow" style="background-color: transparent;" >
        <div class="container">
            <a class="navbar-brand" href="myresumes.php" >
                <img src="./Assets/images/logo-0.png" alt="Logo" height="24" class="d-inline-block align-text-top">
                Resume Builder
            </a>
            <div>
                <a  href="account.php" class="btn btn-sm btn-dark"><i class="bi bi-person-circle"></i> Account</a> 
                <a href="actions/logout.action.php" class="btn btn-sm btn-danger"><i class="bi bi-box-arrow-left"></i></a>
            </div>
        </div>
    </nav>